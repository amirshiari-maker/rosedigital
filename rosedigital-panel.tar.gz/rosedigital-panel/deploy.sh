#!/bin/bash
set -e

echo "🚀 Deploying Rose Digital Panel..."

# 1. کپی فایل‌ها
mkdir -p /opt/rosedigital-panel
cp -r . /opt/rosedigital-panel/
cd /opt/rosedigital-panel

# 2. نصب dependencies
npm install --production

# 3. nginx config
cp nginx.conf /etc/nginx/sites-available/rosedigital-panel
ln -sf /etc/nginx/sites-available/rosedigital-panel /etc/nginx/sites-enabled/rosedigital-panel
nginx -t && systemctl reload nginx

# 4. PM2
pm2 delete rosedigital-panel 2>/dev/null || true
pm2 start src/app.js --name rosedigital-panel
pm2 save

# 5. SSL
certbot --nginx -d my.rosedigital.ir --non-interactive --agree-tos -m info@rosedigital.ir

echo "✅ Done! Panel running at https://my.rosedigital.ir"
