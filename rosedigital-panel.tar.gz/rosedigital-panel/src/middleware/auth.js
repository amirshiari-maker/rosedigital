const jwt = require('jsonwebtoken');
const { db } = require('../models/db');

const SECRET = process.env.JWT_SECRET;

function authMiddleware(req, res, next) {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'احراز هویت نشدید' });

  try {
    const payload = jwt.verify(token, SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id=? AND is_active=1').get(payload.id);
    if (!user) return res.status(401).json({ error: 'کاربر یافت نشد' });
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error: 'توکن نامعتبر است' });
  }
}

function adminMiddleware(req, res, next) {
  authMiddleware(req, res, () => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'دسترسی ندارید' });
    next();
  });
}

function signToken(user) {
  return jwt.sign({ id: user.id, phone: user.phone, role: user.role }, SECRET, { expiresIn: '30d' });
}

module.exports = { authMiddleware, adminMiddleware, signToken };
