const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const { db } = require('../models/db');
const { sendOTP } = require('../utils/sms');
const { signToken } = require('../middleware/auth');

const otpLimiter = rateLimit({ windowMs: 2 * 60 * 1000, max: 3, message: { error: 'تعداد درخواست بیش از حد مجاز' } });

// ارسال کد OTP
router.post('/otp/send', otpLimiter, async (req, res) => {
  let { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'شماره موبایل الزامی است' });

  phone = phone.replace(/\D/g, '');
  if (!/^09\d{9}$/.test(phone)) return res.status(400).json({ error: 'شماره موبایل نامعتبر است' });

  const code = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(Date.now() + 3 * 60 * 1000).toISOString();

  // پاک کردن OTPهای قدیمی
  db.prepare("DELETE FROM otp_codes WHERE phone=? OR expires_at < datetime('now')").run(phone);
  db.prepare('INSERT INTO otp_codes (phone,code,expires_at) VALUES (?,?,?)').run(phone, code, expiresAt);

  const smsResult = await sendOTP(phone, code);

  // در محیط dev کد رو لاگ می‌کنیم
  if (process.env.NODE_ENV !== 'production') console.log(`OTP for ${phone}: ${code}`);

  if (!smsResult.ok) return res.status(500).json({ error: 'خطا در ارسال پیامک' });
  res.json({ ok: true, message: 'کد تأیید ارسال شد' });
});

// تأیید کد OTP و ورود/ثبت‌نام
router.post('/otp/verify', async (req, res) => {
  let { phone, code } = req.body;
  if (!phone || !code) return res.status(400).json({ error: 'اطلاعات ناقص است' });

  phone = phone.replace(/\D/g, '');

  const otp = db.prepare(
    "SELECT * FROM otp_codes WHERE phone=? AND code=? AND used=0 AND expires_at > datetime('now') ORDER BY id DESC LIMIT 1"
  ).get(phone, code);

  if (!otp) return res.status(400).json({ error: 'کد نامعتبر یا منقضی شده' });

  // OTP رو مصرف‌شده کن
  db.prepare('UPDATE otp_codes SET used=1 WHERE id=?').run(otp.id);

  // کاربر وجود داره یا باید ساخته بشه
  let user = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
  const isNew = !user;

  if (!user) {
    const result = db.prepare('INSERT INTO users (phone) VALUES (?)').run(phone);
    user = db.prepare('SELECT * FROM users WHERE id=?').get(result.lastInsertRowid);
  }

  const token = signToken(user);
  res.cookie('token', token, {
    httpOnly: true, secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax', maxAge: 30 * 24 * 60 * 60 * 1000
  });

  res.json({ ok: true, isNew, token, user: { id: user.id, phone: user.phone, name: user.name, role: user.role } });
});

// خروج
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

// پروفایل کاربر جاری
router.get('/me', require('../middleware/auth').authMiddleware, (req, res) => {
  const { id, phone, name, email, role, created_at } = req.user;
  res.json({ id, phone, name, email, role, created_at });
});

// آپدیت پروفایل
router.put('/profile', require('../middleware/auth').authMiddleware, (req, res) => {
  const { name, email } = req.body;
  db.prepare('UPDATE users SET name=?, email=?, updated_at=datetime("now") WHERE id=?').run(name, email, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
