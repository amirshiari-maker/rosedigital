const router = require('express').Router();
const { db } = require('../models/db');
const { adminMiddleware } = require('../middleware/auth');
const { generateLicenseKey, getExpiryDate } = require('../utils/license');

router.use(adminMiddleware);

// آمار کلی
router.get('/stats', (req, res) => {
  const stats = {
    users:    db.prepare('SELECT COUNT(*) as c FROM users').get().c,
    licenses: db.prepare("SELECT COUNT(*) as c FROM licenses WHERE status='active'").get().c,
    orders:   db.prepare("SELECT COUNT(*) as c FROM orders WHERE status='paid'").get().c,
    revenue:  db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM orders WHERE status='paid'").get().s,
    tickets:  db.prepare("SELECT COUNT(*) as c FROM tickets WHERE status='open'").get().c,
  };
  res.json(stats);
});

// لیست کاربران
router.get('/users', (req, res) => {
  const users = db.prepare(`
    SELECT u.*, 
      COUNT(DISTINCT l.id) as license_count,
      COUNT(DISTINCT o.id) as order_count
    FROM users u
    LEFT JOIN licenses l ON l.user_id=u.id
    LEFT JOIN orders o ON o.user_id=u.id AND o.status='paid'
    GROUP BY u.id ORDER BY u.created_at DESC
  `).all();
  res.json(users);
});

// فعال/غیرفعال کردن کاربر
router.patch('/users/:id/toggle', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'کاربر یافت نشد' });
  db.prepare('UPDATE users SET is_active=? WHERE id=?').run(user.is_active ? 0 : 1, user.id);
  res.json({ ok: true });
});

// لیست لایسنس‌ها
router.get('/licenses', (req, res) => {
  const licenses = db.prepare(`
    SELECT l.*, u.phone, u.name FROM licenses l
    JOIN users u ON u.id=l.user_id ORDER BY l.created_at DESC
  `).all();
  res.json(licenses);
});

// صدور لایسنس دستی
router.post('/licenses', (req, res) => {
  const { user_id, plan, studio_name } = req.body;
  if (!user_id) return res.status(400).json({ error: 'user_id الزامی است' });

  const key       = generateLicenseKey();
  const expiresAt = getExpiryDate(plan || 'yearly');

  const lic = db.prepare(`
    INSERT INTO licenses (user_id, license_key, plan, status, studio_name, expires_at, activated_at)
    VALUES (?,?,?,  'active',?,?,datetime('now'))
  `).run(user_id, key, plan || 'yearly', studio_name || null, expiresAt);

  res.json({ ok: true, id: lic.lastInsertRowid, license_key: key });
});

// تغییر وضعیت لایسنس
router.patch('/licenses/:id', (req, res) => {
  const { status } = req.body;
  if (!['active','suspended','expired'].includes(status)) return res.status(400).json({ error: 'وضعیت نامعتبر' });
  db.prepare('UPDATE licenses SET status=?, updated_at=datetime("now") WHERE id=?').run(status, req.params.id);
  res.json({ ok: true });
});

// لیست سفارشات
router.get('/orders', (req, res) => {
  const orders = db.prepare(`
    SELECT o.*, u.phone, u.name FROM orders o
    JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC
  `).all();
  res.json(orders);
});

// تیکت‌ها
router.get('/tickets', (req, res) => {
  const { status } = req.query;
  const where = status ? 'WHERE t.status=?' : '';
  const tickets = db.prepare(`
    SELECT t.*, u.phone, u.name,
      (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=t.id) as msg_count
    FROM tickets t JOIN users u ON u.id=t.user_id
    ${where} ORDER BY t.updated_at DESC
  `).all(...(status ? [status] : []));
  res.json(tickets);
});

// پاسخ ادمین به تیکت
router.post('/tickets/:id/reply', (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'متن الزامی است' });

  const ticket = db.prepare('SELECT * FROM tickets WHERE id=?').get(req.params.id);
  if (!ticket) return res.status(404).json({ error: 'تیکت یافت نشد' });

  db.prepare('INSERT INTO ticket_messages (ticket_id, is_admin, message) VALUES (?,1,?)').run(ticket.id, message);
  db.prepare("UPDATE tickets SET status='answered', updated_at=datetime('now') WHERE id=?").run(ticket.id);

  res.json({ ok: true });
});

// بستن تیکت
router.patch('/tickets/:id/close', (req, res) => {
  db.prepare("UPDATE tickets SET status='closed', updated_at=datetime('now') WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

// ست کردن ادمین
router.patch('/users/:id/role', (req, res) => {
  const { role } = req.body;
  if (!['user','admin'].includes(role)) return res.status(400).json({ error: 'نقش نامعتبر' });
  db.prepare('UPDATE users SET role=? WHERE id=?').run(role, req.params.id);
  res.json({ ok: true });
});

module.exports = router;
