const router = require('express').Router();
const { db } = require('../models/db');
const { authMiddleware } = require('../middleware/auth');

// همه route‌ها نیاز به auth دارن
router.use(authMiddleware);

// داشبورد — سفارشات و لایسنس‌ها
router.get('/dashboard', (req, res) => {
  const licenses = db.prepare('SELECT * FROM licenses WHERE user_id=? ORDER BY created_at DESC').all(req.user.id);
  const orders   = db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT 10').all(req.user.id);
  const tickets  = db.prepare('SELECT * FROM tickets WHERE user_id=? ORDER BY updated_at DESC LIMIT 5').all(req.user.id);

  res.json({ licenses, orders, tickets });
});

// لیست لایسنس‌ها
router.get('/licenses', (req, res) => {
  const licenses = db.prepare('SELECT * FROM licenses WHERE user_id=? ORDER BY created_at DESC').all(req.user.id);
  res.json(licenses);
});

// لیست سفارشات
router.get('/orders', (req, res) => {
  const orders = db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC').all(req.user.id);
  res.json(orders);
});

// تیکت‌ها
router.get('/tickets', (req, res) => {
  const tickets = db.prepare(`
    SELECT t.*, 
      (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=t.id) as msg_count,
      (SELECT message FROM ticket_messages WHERE ticket_id=t.id ORDER BY id DESC LIMIT 1) as last_message
    FROM tickets t WHERE t.user_id=? ORDER BY t.updated_at DESC
  `).all(req.user.id);
  res.json(tickets);
});

// ساخت تیکت جدید
router.post('/tickets', (req, res) => {
  const { subject, message, priority } = req.body;
  if (!subject || !message) return res.status(400).json({ error: 'موضوع و متن الزامی است' });

  const ticket = db.prepare(`
    INSERT INTO tickets (user_id, subject, priority) VALUES (?,?,?)
  `).run(req.user.id, subject, priority || 'normal');

  db.prepare(`
    INSERT INTO ticket_messages (ticket_id, user_id, message) VALUES (?,?,?)
  `).run(ticket.lastInsertRowid, req.user.id, message);

  res.json({ ok: true, id: ticket.lastInsertRowid });
});

// پیام‌های تیکت
router.get('/tickets/:id', (req, res) => {
  const ticket = db.prepare('SELECT * FROM tickets WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!ticket) return res.status(404).json({ error: 'تیکت یافت نشد' });

  const messages = db.prepare('SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY created_at').all(ticket.id);
  res.json({ ticket, messages });
});

// پاسخ به تیکت
router.post('/tickets/:id/reply', (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'متن پیام الزامی است' });

  const ticket = db.prepare('SELECT * FROM tickets WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!ticket) return res.status(404).json({ error: 'تیکت یافت نشد' });
  if (ticket.status === 'closed') return res.status(400).json({ error: 'تیکت بسته شده' });

  db.prepare('INSERT INTO ticket_messages (ticket_id, user_id, message) VALUES (?,?,?)').run(ticket.id, req.user.id, message);
  db.prepare("UPDATE tickets SET status='open', updated_at=datetime('now') WHERE id=?").run(ticket.id);

  res.json({ ok: true });
});

module.exports = router;
