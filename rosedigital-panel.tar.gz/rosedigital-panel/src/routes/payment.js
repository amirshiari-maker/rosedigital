const router = require('express').Router();
const axios = require('axios');
const { db } = require('../models/db');
const { authMiddleware } = require('../middleware/auth');
const { generateLicenseKey, getExpiryDate } = require('../utils/license');
const { sendText } = require('../utils/sms');

const PAYPING_TOKEN = process.env.PAYPING_TOKEN;
const CALLBACK_URL  = process.env.PAYPING_CALLBACK_URL;

const PRODUCTS = {
  fotopanel_yearly: { name: 'فتوپنل — لایسنس سالانه', amount: 3000000, type: 'fotopanel', plan: 'yearly' },
};

// شروع پرداخت
router.post('/create', authMiddleware, async (req, res) => {
  const { productId } = req.body;
  const product = PRODUCTS[productId];
  if (!product) return res.status(400).json({ error: 'محصول یافت نشد' });

  // ثبت سفارش اولیه
  const order = db.prepare(`
    INSERT INTO orders (user_id, product_type, product_name, amount, status)
    VALUES (?, ?, ?, ?, 'pending')
  `).run(req.user.id, product.type, product.name, product.amount);

  try {
    const { data } = await axios.post(
      'https://api.payping.ir/v2/pay',
      {
        amount: Math.round(product.amount / 10),
        returnUrl: `${CALLBACK_URL}?orderId=${order.lastInsertRowid}`,
        description: product.name,
        payerName: req.user.name || '',
        payerIdentity: req.user.phone,
        clientRefId: String(order.lastInsertRowid)
      },
      { headers: { Authorization: `Bearer ${PAYPING_TOKEN}`, 'Content-Type': 'application/json' } }
    );

    if (data?.code) {
      db.prepare('UPDATE orders SET payping_code=? WHERE id=?').run(data.code, order.lastInsertRowid);
      return res.json({ ok: true, url: `https://api.payping.ir/v2/pay/gotoipg/${data.code}` });
    }
    throw new Error('No code from PayPing');
  } catch (err) {
    console.error('PayPing error:', err?.response?.data || err.message);
    db.prepare("UPDATE orders SET status='failed' WHERE id=?").run(order.lastInsertRowid);
    res.status(500).json({ error: 'خطا در اتصال به درگاه پرداخت' });
  }
});

// callback پرداخت
router.get('/verify', async (req, res) => {
  const { orderId, refid } = req.query;
  if (!orderId || !refid) return res.redirect('/panel?payment=failed');

  const order = db.prepare('SELECT * FROM orders WHERE id=?').get(orderId);
  if (!order || order.status !== 'pending') return res.redirect('/panel?payment=failed');

  try {
    const { data } = await axios.post(
      'https://api.payping.ir/v2/pay/verify',
      { amount: Math.round(order.amount / 10), refId: refid },
      { headers: { Authorization: `Bearer ${PAYPING_TOKEN}`, 'Content-Type': 'application/json' } }
    );

    if (data?.amount) {
      // پرداخت موفق — لایسنس بساز
      const licenseKey = generateLicenseKey();
      const expiresAt  = getExpiryDate('yearly');

      const lic = db.prepare(`
        INSERT INTO licenses (user_id, license_key, plan, status, expires_at, activated_at)
        VALUES (?, ?, 'yearly', 'active', ?, datetime('now'))
      `).run(order.user_id, licenseKey, expiresAt);

      db.prepare(`
        UPDATE orders SET status='paid', payment_ref=?, license_id=?, updated_at=datetime('now') WHERE id=?
      `).run(refid, lic.lastInsertRowid, order.id);

      // ارسال SMS به کاربر
      const user = db.prepare('SELECT * FROM users WHERE id=?').get(order.user_id);
      if (user?.phone) {
        await sendText(user.phone,
          `فتوپنل خریداری شد 🎉\nلایسنس شما:\n${licenseKey}\nاعتبار تا: ${expiresAt.slice(0,10)}\nmy.rosedigital.ir`
        );
      }

      return res.redirect(`/panel?payment=success&license=${licenseKey}`);
    }

    throw new Error('Verification failed');
  } catch (err) {
    console.error('Verify error:', err?.response?.data || err.message);
    db.prepare("UPDATE orders SET status='failed' WHERE id=?").run(order.id);
    res.redirect('/panel?payment=failed');
  }
});

module.exports = router;
