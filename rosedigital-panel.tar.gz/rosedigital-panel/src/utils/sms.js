const axios = require('axios');

const API_KEY = process.env.SMS_API_KEY;
const LINE    = process.env.SMS_LINE;

async function sendOTP(phone, code) {
  try {
    const res = await axios.post(
      'https://api.sms.ir/v1/send/verify',
      {
        mobile: phone,
        templateId: 100000,
        parameters: [{ name: 'Code', value: String(code) }]
      },
      { headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' } }
    );
    return { ok: true, data: res.data };
  } catch (err) {
    console.error('SMS error:', err?.response?.data || err.message);
    return { ok: false, error: err?.response?.data };
  }
}

async function sendText(phone, message) {
  try {
    const res = await axios.post(
      'https://api.sms.ir/v1/send/bulk',
      { lineNumber: LINE, MessageTexts: [message], Mobiles: [phone] },
      { headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' } }
    );
    return { ok: true };
  } catch (err) {
    console.error('SMS error:', err?.response?.data || err.message);
    return { ok: false };
  }
}

module.exports = { sendOTP, sendText };
