const crypto = require('crypto');

function generateLicenseKey() {
  const seg = () => crypto.randomBytes(3).toString('hex').toUpperCase();
  return `FP-${seg()}-${seg()}-${seg()}-${seg()}`;
}

function getExpiryDate(plan = 'yearly') {
  const d = new Date();
  if (plan === 'yearly')  d.setFullYear(d.getFullYear() + 1);
  if (plan === 'monthly') d.setMonth(d.getMonth() + 1);
  if (plan === 'lifetime') d.setFullYear(d.getFullYear() + 99);
  return d.toISOString();
}

module.exports = { generateLicenseKey, getExpiryDate };
