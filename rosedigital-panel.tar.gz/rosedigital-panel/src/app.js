require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const express    = require('express');
const helmet     = require('helmet');
const cors       = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const { init }   = require('./models/db');

const app = express();

// ── Init DB
init();

// ── Security
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.SITE_URL, credentials: true }));
app.use(rateLimit({ windowMs: 60 * 1000, max: 120 }));

// ── Body / Cookie
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// ── Static (frontend)
app.use(express.static(path.join(__dirname, '../public')));

// ── API Routes
app.use('/api/auth',    require('./routes/auth'));
app.use('/api/user',    require('./routes/user'));
app.use('/api/payment', require('./routes/payment'));
app.use('/api/admin',   require('./routes/admin'));

// ── Health check
app.get('/api/health', (req, res) => res.json({ ok: true, ts: new Date().toISOString() }));

// ── SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ── Start
const PORT = process.env.PORT || 4001;
app.listen(PORT, () => console.log(`🚀 Rose Digital Panel running on port ${PORT}`));
