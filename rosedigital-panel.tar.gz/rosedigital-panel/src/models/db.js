const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = process.env.DB_PATH || './data/panel.db';
const dir = path.dirname(dbPath);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function init() {
  db.exec(`
    -- کاربران
    CREATE TABLE IF NOT EXISTS users (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      phone       TEXT UNIQUE NOT NULL,
      name        TEXT,
      email       TEXT,
      password    TEXT,
      role        TEXT DEFAULT 'user',
      is_active   INTEGER DEFAULT 1,
      created_at  TEXT DEFAULT (datetime('now')),
      updated_at  TEXT DEFAULT (datetime('now'))
    );

    -- کدهای OTP
    CREATE TABLE IF NOT EXISTS otp_codes (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      phone       TEXT NOT NULL,
      code        TEXT NOT NULL,
      expires_at  TEXT NOT NULL,
      used        INTEGER DEFAULT 0,
      created_at  TEXT DEFAULT (datetime('now'))
    );

    -- لایسنس‌های فتوپنل
    CREATE TABLE IF NOT EXISTS licenses (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id       INTEGER NOT NULL REFERENCES users(id),
      license_key   TEXT UNIQUE NOT NULL,
      plan          TEXT DEFAULT 'yearly',
      status        TEXT DEFAULT 'active',
      studio_name   TEXT,
      expires_at    TEXT NOT NULL,
      activated_at  TEXT,
      created_at    TEXT DEFAULT (datetime('now')),
      updated_at    TEXT DEFAULT (datetime('now'))
    );

    -- سفارشات
    CREATE TABLE IF NOT EXISTS orders (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id       INTEGER NOT NULL REFERENCES users(id),
      product_type  TEXT NOT NULL,
      product_name  TEXT NOT NULL,
      amount        INTEGER NOT NULL,
      status        TEXT DEFAULT 'pending',
      payment_ref   TEXT,
      payping_code  TEXT,
      license_id    INTEGER REFERENCES licenses(id),
      created_at    TEXT DEFAULT (datetime('now')),
      updated_at    TEXT DEFAULT (datetime('now'))
    );

    -- تیکت‌های پشتیبانی
    CREATE TABLE IF NOT EXISTS tickets (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id     INTEGER NOT NULL REFERENCES users(id),
      subject     TEXT NOT NULL,
      status      TEXT DEFAULT 'open',
      priority    TEXT DEFAULT 'normal',
      created_at  TEXT DEFAULT (datetime('now')),
      updated_at  TEXT DEFAULT (datetime('now'))
    );

    -- پیام‌های تیکت
    CREATE TABLE IF NOT EXISTS ticket_messages (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_id   INTEGER NOT NULL REFERENCES tickets(id),
      user_id     INTEGER REFERENCES users(id),
      is_admin    INTEGER DEFAULT 0,
      message     TEXT NOT NULL,
      created_at  TEXT DEFAULT (datetime('now'))
    );

    -- ایندکس‌ها
    CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
    CREATE INDEX IF NOT EXISTS idx_otp_phone ON otp_codes(phone);
    CREATE INDEX IF NOT EXISTS idx_licenses_user ON licenses(user_id);
    CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_tickets_user ON tickets(user_id);
  `);

  console.log('✅ Database initialized');
}

module.exports = { db, init };
